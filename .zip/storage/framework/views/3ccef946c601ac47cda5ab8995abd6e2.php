<?php
$tours = [
    [
        'image' => '/images/Borobudur.jpg',
        'title' => 'Borobudur',
        'location' => 'Magelang, Jawa Tengah',
        'price' => 'Rp 500.000',
        'stokKursi' => 20
    ],
    [
        'image' => '/images/Borobudur.jpg',
        'title' => 'Bali Paradise',
        'location' => 'Bali, Indonesia',
        'price' => 'Rp 3.500.000',
        'stokKursi' => 12
    ],
    [
        'image' => '/images/Borobudur.jpg',
        'title' => 'Lombok Escape',
        'location' => 'Lombok, Indonesia',
        'price' => 'Rp 4.200.000',
        'stokKursi' => 8
    ],
    [
        'image' => '/images/Borobudur.jpg',
        'title' => 'Lombok Escape',
        'location' => 'Lombok, Indonesia',
        'price' => 'Rp 4.200.000',
        'stokKursi' => 8
    ],
    [
        'image' => '/images/Bali.jpg',
        'title' => 'Lombok Escape',
        'location' => 'Lombok, Indonesia',
        'price' => 'Rp 4.200.000',
        'stokKursi' => 8
    ],
];
?>



<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="px-10 py-16">
    <h2 class="text-4xl font-serif mb-6">
        Mulai Petualangan Impianmu
    </h2>

    <?php if (isset($component)) { $__componentOriginal95d20aa55f24eeccea250353dc2e802d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal95d20aa55f24eeccea250353dc2e802d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tourSlider','data' => ['tours' => $tours]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tourSlider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tours' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tours)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal95d20aa55f24eeccea250353dc2e802d)): ?>
<?php $attributes = $__attributesOriginal95d20aa55f24eeccea250353dc2e802d; ?>
<?php unset($__attributesOriginal95d20aa55f24eeccea250353dc2e802d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal95d20aa55f24eeccea250353dc2e802d)): ?>
<?php $component = $__componentOriginal95d20aa55f24eeccea250353dc2e802d; ?>
<?php unset($__componentOriginal95d20aa55f24eeccea250353dc2e802d); ?>
<?php endif; ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/pages/home.blade.php ENDPATH**/ ?>