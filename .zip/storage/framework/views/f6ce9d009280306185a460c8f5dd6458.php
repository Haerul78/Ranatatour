<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <meta charset="UTF-8">
</head>
<body class="bg-[#F5EFE6]">
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/layout/main.blade.php ENDPATH**/ ?>