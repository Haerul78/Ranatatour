<div 
x-data="{ current: 0, perPage: 4 }"
class="relative overflow-hidden"
>
    <div
        class="flex transition-transform duration-500 ease-in-out"
        :style="`transform: translateX(-${current * 25}%)`"
    >

        <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-1/4 px-3 shrink-0">
                <?php echo $__env->make('components.tourCard', $tour, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <button @click="if(current > 0) current--"
        class="absolute left-0 top-1/2 translate-y-1/2 bg-white shadow w-10 h-10 rounded-full">
        ⬅️
    </button>

    <button @click="if(current < <?php echo e(count($tours)); ?>  - perPage) current++"
        class="absolute right-0 top-1/2 translate-y-1/2 bg-white shadow w-10 h-10 rounded-full">
        ➡️
    </button>
</div><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/components/tourSlider.blade.php ENDPATH**/ ?>