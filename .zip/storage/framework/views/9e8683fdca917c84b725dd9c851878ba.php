<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rana Tour Travel</title>
</head>
<body>

    <h1>Selamat Datang di Rana Tour</h1>
    <p>Website portal travel kamu 🚀</p>

</body>
</html><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/welcome.blade.php ENDPATH**/ ?>