<div x-data="{ scrollX: 0 }" class="relative">
    <div
        x-ref="slider"
        class="flex gap-6 overflow-hidden scroll-smooth"
    >
        <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('components.tourCard', [
                'image' => $tour['image'],
                'title' => $tour['title'],
                'location' => $tour['location'],
                'price' => $tour['price'],
                'stokKursi' => $tour['stokKursi']
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button
        @click="$refs.slider.scrollBy({ left: 300, behavior: 'smooth' })"
        class="absolute right-0 top-1/2 -translate-y-1/2 bg-white shadow rounded-full w-10 h-10 flex items-center justify-center"
        >
        -->
    </button>
</div><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/components/tourslider.blade.php ENDPATH**/ ?>