<nav 
class="flex justify-between items-center px-10 py-5 fixed top-0 w-full z-50 transition-all duration-300"
x-data="{ scrolled: false }"
x-init="window.addEventListener('scroll', () => scrolled = window.scrollY > 50)"
:class="scrolled ? 'bg-white shadow-md' : 'bg-transparent'">
    <h1 class="text-2xl font-bold">
        <img src="/images/LOGO RANATA.svg" alt="Ranata Tour Logo" class="w-10 h-10 inline-block" >
        <span class="text-merah-ranata">Ranata</span><span :class='scrolled ? "text-gray-800" : "text-white"'>tour</span>
    </h1>

    <ul class="flex gap-8"
    :class="scrolled ? 'text-gray-800' : 'text-white'">
        <li>Home</li>
        <li>Destinations</li>
        <li>Activities</li>
        <li>About Us</li>
        <li>Contact</li>
    </ul>

    <button class="bg-merah-ranata text-white px-4 py-2 rounded-md hover:bg-red-700"
    @click="alert('Get Started')">
        Get Started
    </button>
</nav><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/components/navbar.blade.php ENDPATH**/ ?>