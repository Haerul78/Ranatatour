<section class="relative h-screen">
    <img src="/images/Borobudur.jpg" alt="Borobudur" class="absolute w-full h-full object-cover">
    <div class="absolute inset-0 bg-black/40"></div>
    
    <div class="relative z-10 text-white px-16 pt-70">
        <h1 class="text-6xl font-serif leading-tight">
            Ibu kota yang <br>
            Penuh <span class="text-merah-ranata">Warna</span>
            Cerita, dan <br>
            <span class="text-merah-ranata">Kehidupan</span>
        </h1>

        <p class="mt-5 max-w-lg">
            Jelajahi keindahan dan keunikan Jakarta, kota yang memikat dengan pesona budaya, sejarah, dan kehidupan modernnya.
        </p>

        <button class="mt-5 bg-merah-ranata px-6 py-3 rounded-lg hover:bg-red-700">
            lihat semua destinasi
        </button>
    </div>
</section><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/components/hero.blade.php ENDPATH**/ ?>