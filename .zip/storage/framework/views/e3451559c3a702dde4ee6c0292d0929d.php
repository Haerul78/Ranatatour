<div class="bg-white rounded-xl shadow">
    <div>
        <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>" class="rounded-t-lg mb-3">
    </div>
    <div class="px-4 pb-4">
        <h3 class="font-semibold"><?php echo e($title); ?></h3>
        <div class="flex items-center gap-2 text-gray-500 text-sm mb-10">
    
            <!-- ICON -->
            <svg xmlns="http://www.w3.org/2000/svg" 
                 class="w-4 h-4 text-merah-ranata" 
                 fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                      d="M17.657 16.657L13.414 20.9a2 2 0 01-2.828 0l-4.243-4.243a8 8 0 1111.314 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>

            <span><?php echo e($location); ?></span>
        </div>

        <hr class="my-3 border-gray-200">
        <div class="mt-2 ">
            <p>Mulai dari</p>
            <div class="flex justify-between items-center">
                <p class="text-merah-ranata font-bold"><?php echo e($price); ?></p>
                <p><?php echo e($stokKursi); ?> kursi tersedia</p>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Haerul\Magang2\ranatatour-app\resources\views/components/tourCard.blade.php ENDPATH**/ ?>