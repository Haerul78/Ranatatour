export default function Home() {
    return (
        <div>
            Selamat datang
        </div>
    );
}